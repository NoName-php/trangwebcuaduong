const $=(s)=>document.querySelector(s), $$=(s)=>[...document.querySelectorAll(s)];
const STORAGE={words:"vm_words_v5",progress:"vm_progress_v5",settings:"vm_settings_v5"};

const SAMPLE=[
{word:"abandon",phonetic:"/əˈbændən/",meaning:"từ bỏ, bỏ rơi",context:"abandon hope = từ bỏ hi vọng",synonyms:["leave","desert","forsake"],example:"He abandoned the plan after the first failure.",note:"Động từ; thường dùng khi ngừng hoàn toàn một kế hoạch hoặc rời bỏ một nơi/người."},
{word:"assess",phonetic:"/əˈses/",meaning:"đánh giá, thẩm định",context:"assess the impact/risk = đánh giá tác động/rủi ro",synonyms:["evaluate","judge","appraise"],example:"Teachers assess students' progress throughout the course.",note:"Rất hay gặp trong IELTS Academic và văn viết học thuật."},
{word:"prominent",phonetic:"/ˈprɒmɪnənt/",meaning:"nổi bật, đáng chú ý",context:"a prominent feature = một đặc điểm nổi bật",synonyms:["notable","eminent","distinguished"],example:"The tower is a prominent feature of the city.",note:"Có thể dùng cho người, vị trí hoặc đặc điểm dễ nhận thấy."},
{word:"acquisition",phonetic:"/ˌækwɪˈzɪʃən/",meaning:"sự tiếp thu, sự đạt được, việc mua lại",context:"language acquisition = việc tiếp thu ngôn ngữ",synonyms:["attainment","purchase","procurement"],example:"Language acquisition is influenced by repeated exposure.",note:"Trong giáo dục, language acquisition thường nói về quá trình tiếp thu ngôn ngữ."},
{word:"ominous",phonetic:"/ˈɒmɪnəs/",meaning:"điềm gở, báo hiệu điều xấu",context:"an ominous sign = một dấu hiệu đáng ngại",synonyms:["menacing","threatening","foreboding"],example:"Dark clouds were an ominous sign of the approaching storm.",note:"Dùng khi một dấu hiệu khiến người ta lo rằng chuyện xấu sắp xảy ra."},
{word:"contemporary",phonetic:"/kənˈtempərəri/",meaning:"đương đại, thuộc thời hiện tại",context:"contemporary society = xã hội đương đại",synonyms:["modern","current","present-day"],example:"The novel explores issues in contemporary society.",note:"Cũng có thể mang nghĩa 'đương thời' khi hai người/sự kiện cùng thời."},
{word:"promote",phonetic:"/prəˈməʊt/",meaning:"thúc đẩy, khuyến khích; thăng chức",context:"promote healthy habits = thúc đẩy thói quen lành mạnh",synonyms:["encourage","advance","support"],example:"The campaign aims to promote healthy eating.",note:"Trong bài học thuật thường gặp nhất là 'thúc đẩy/khuyến khích'."},
{word:"decline",phonetic:"/dɪˈklaɪn/",meaning:"suy giảm; từ chối",context:"a decline in sales = sự suy giảm doanh số",synonyms:["decrease","drop","deteriorate"],example:"There was a sharp decline in the number of visitors.",note:"Danh từ và động từ đều dùng phổ biến."},
{word:"inevitable",phonetic:"/ɪnˈevɪtəbl/",meaning:"không thể tránh khỏi",context:"an inevitable consequence = hệ quả không thể tránh khỏi",synonyms:["unavoidable","certain","inescapable"],example:"Some degree of change is inevitable.",note:"Hay dùng khi nói một kết quả chắc chắn sẽ xảy ra."},
{word:"enhance",phonetic:"/ɪnˈhɑːns/",meaning:"nâng cao, tăng cường, cải thiện",context:"enhance performance = nâng cao hiệu suất",synonyms:["improve","boost","strengthen"],example:"Regular practice can enhance your speaking skills.",note:"Thường mang sắc thái làm một thứ đã có trở nên tốt hơn."},
{word:"allocate",phonetic:"/ˈæləkeɪt/",meaning:"phân bổ",context:"allocate resources = phân bổ nguồn lực",synonyms:["assign","distribute","apportion"],example:"The government allocated more money to education.",note:"Rất phổ biến trong văn học thuật, kinh tế và biểu đồ IELTS."},
{word:"coherent",phonetic:"/kəʊˈhɪərənt/",meaning:"mạch lạc, rõ ràng và có liên kết",context:"a coherent argument = lập luận mạch lạc",synonyms:["logical","consistent","clear"],example:"Your essay needs a more coherent structure.",note:"Từ quan trọng khi đánh giá bài viết/nói."}
];

let words=[],progress={answered:0,correct:0,streak:0,mastered:0,lastStudy:0,milestones:0,cards:{}};
let settings={notifications:false,awayReminder:true,reminderTimes:["09:00","15:00","20:00"]};
let currentScreen="home",currentQuizMode="smart";
let quiz={deck:[],index:0,score:0,answered:false,mode:"smart",question:null,options:[],correctIndex:-1};
let fc={deck:[],index:0};

const MODE_LABELS={meaning:"English → Vietnamese",reverse:"Vietnamese → English",cloze:"Fill in the blank",synonym:"Synonym",listening:"Listening",context:"Context",smart:"Smart Quiz",mixed:"Mixed Quiz"};

function loadState(){
  try{words=JSON.parse(localStorage.getItem(STORAGE.words)||"[]");progress={...progress,...JSON.parse(localStorage.getItem(STORAGE.progress)||"{}")};progress.cards=progress.cards||{};settings={...settings,...JSON.parse(localStorage.getItem(STORAGE.settings)||"{}")};}catch(e){console.warn(e)}
}
function saveState(){localStorage.setItem(STORAGE.words,JSON.stringify(words));localStorage.setItem(STORAGE.progress,JSON.stringify(progress));localStorage.setItem(STORAGE.settings,JSON.stringify(settings))}
function uid(){return crypto.randomUUID?.()||`${Date.now()}-${Math.random().toString(16).slice(2)}`}
function norm(w){return{ id:w.id||uid(),word:String(w.word||"").trim(),phonetic:String(w.phonetic||"").trim(),meaning:String(w.meaning||"").trim(),context:String(w.context||"").trim(),synonyms:Array.isArray(w.synonyms)?w.synonyms.filter(Boolean).map(String):String(w.synonyms||"").split(/[;,]/).map(s=>s.trim()).filter(Boolean),example:String(w.example||"").trim(),note:String(w.note||"").trim()}}
function ensure(w){progress.cards[w.id]??={correct:0,wrong:0,box:0,due:0};return progress.cards[w.id]}
function shuffle(a){a=[...a];for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a}
function esc(s){return String(s||"").replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function speak(text){if(!("speechSynthesis"in window))return toast("Thiết bị không hỗ trợ đọc.");speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.lang="en-US";u.rate=.88;speechSynthesis.speak(u)}
function toast(msg){const t=$("#toast");t.textContent=msg;t.hidden=false;clearTimeout(window.__toast);window.__toast=setTimeout(()=>t.hidden=true,2300)}
function dueWords(){const now=Date.now();return words.filter(w=>(ensure(w).due||0)<=now)}
function weakWords(){return words.filter(w=>ensure(w).wrong>0).sort((a,b)=>{const A=ensure(a),B=ensure(b);return (B.wrong-B.correct)-(A.wrong-A.correct)} )}
function go(screen){
  currentScreen=screen;$$(".screen").forEach(s=>s.classList.remove("active"));$("#screen-"+screen).classList.add("active");scrollTo(0,0);
  if(screen==="home")renderHome();if(screen==="quiz")startQuiz(currentQuizMode);if(screen==="flashcards")startFlashcards();if(screen==="stats")renderStats();if(screen==="mistakes")renderMistakes();if(screen==="settings")renderSettings();
}
$$("[data-go]").forEach(b=>b.addEventListener("click",()=>go(b.dataset.go)));
$("#homeBtn").addEventListener("click",()=>go("home"));$("#notifBtn").addEventListener("click",()=>go("settings"));

function renderHome(){
  $("#statWords").textContent=words.length;$("#statAnswered").textContent=progress.answered;$("#statAccuracy").textContent=progress.answered?Math.round(progress.correct/progress.answered*100)+"%":"0%";$("#statStreak").textContent=(progress.streak||0)+" 🔥";
}
$("#startSmartBtn").addEventListener("click",()=>go("quiz"));
$("#startMixedBtn").addEventListener("click",()=>{currentQuizMode="mixed";go("quiz")});
$$("[data-mode]").forEach(b=>b.addEventListener("click",()=>{currentQuizMode=b.dataset.mode;go("quiz")}));

function smartMode(){
  const pool=weakWords().slice(0,8);const modes=["meaning","reverse","cloze","synonym","listening","context"];
  if(pool.length && Math.random()<.7)return modes[Math.floor(Math.random()*modes.length)];
  return modes[Math.floor(Math.random()*modes.length)];
}
function buildDeck(mode){
  let pool=mode==="smart"?dueWords():mode==="mixed"?dueWords().length?dueWords():words:words;
  if(!pool.length)pool=words;
  if(weakWords().length)pool=[...weakWords().slice(0,6),...pool];
  pool=Array.from(new Map(pool.map(w=>[w.id,w])).values());
  return shuffle(pool).slice(0,Math.min(10,pool.length));
}
function startQuiz(mode="smart"){
  if(words.length<4){$("#quizEmpty").hidden=false;$("#quizContent").hidden=true;return}
  $("#quizEmpty").hidden=true;$("#quizContent").hidden=false;
  quiz={deck:buildDeck(mode),index:0,score:0,answered:false,mode,question:null,options:[],correctIndex:-1};
  renderQuizQuestion();
}
$$("[data-quiz-mode]").forEach(b=>b.addEventListener("click",()=>{currentQuizMode=b.dataset.quizMode;$$("[data-quiz-mode]").forEach(x=>x.classList.toggle("active",x===b));startQuiz(currentQuizMode)}));
$("#shuffleQuizBtn").addEventListener("click",()=>startQuiz(currentQuizMode));

function distractorWords(target,count=3){return shuffle(words.filter(w=>w.id!==target.id)).slice(0,count)}
function optionsFromWords(items,field){return shuffle(items.map(w=>({id:w.id,text:w[field]||w.word,word:w})))}
// Chỉ hiển thị từ vựng chính trong thẻ câu hỏi; bỏ dấu đầu dòng, loại từ và phần nghĩa nếu bị nhập chung.
function displayHeadWord(value){
  return String(value||"").replace(/^\s*[*•\-]+\s*/,"").split(/[:：]/,1)[0].replace(/\s*\((?:adj|adv|n|noun|verb|v|adjective|adverb|vi|vt|n\.)\)\s*/ig," ").trim();
}
function makeQuestion(w,mode){
  if(mode==="smart")mode=smartMode();
  if(mode==="mixed"){const m=["meaning","reverse","cloze","synonym","listening","context"];mode=m[Math.floor(Math.random()*m.length)]}
  const q={mode,target:w,prompt:"",displayWord:"",phonetic:w.phonetic||"",cloze:""};
  if(mode==="meaning"){
    q.prompt="Chọn nghĩa đúng nhất của từ sau:";q.displayWord=displayHeadWord(w.word);q.options=optionsFromWords([w,...distractorWords(w)],"meaning")
  }else if(mode==="reverse"){
    q.prompt="Chọn từ tiếng Anh phù hợp với nghĩa sau:";q.displayWord=w.meaning;q.options=optionsFromWords([w,...distractorWords(w)],"word")
  }else if(mode==="cloze"){
    q.prompt="Chọn từ phù hợp nhất để điền vào chỗ trống:";q.displayWord="";q.cloze=(w.example||`This sentence uses the word "${w.word}".`).replace(new RegExp(`\\b${w.word.replace(/[.*+?^${}()|[\\]\\\\]/g,'\\\\$&')}\\b`,"i"),"_____");q.options=optionsFromWords([w,...distractorWords(w)],"word")
  }else if(mode==="synonym"){
    const good=w.synonyms?.[0]||"";
    if(!good){return makeQuestion(w,"meaning")}
    const pool=shuffle(words.filter(x=>x.id!==w.id&&x.synonyms?.length)).slice(0,3);
    q.prompt=`Từ nào gần nghĩa nhất với “${w.word}”?`;q.displayWord=w.word;
    q.options=shuffle([{id:"syn-"+w.id,text:good,word:w,isSyn:true},...pool.map(x=>({id:"syn-"+x.id,text:x.synonyms[0],word:x,isSyn:false}))])
  }else if(mode==="listening"){
    q.prompt="Nghe phát âm và chọn từ bạn vừa nghe:";q.displayWord="🎧";q.options=optionsFromWords([w,...distractorWords(w)],"word")
  }else if(mode==="context"){
    q.prompt=`Trong ngữ cảnh “${w.context||w.example||w.word}”, từ “${w.word}” gần nghĩa nào nhất?`;q.displayWord=w.word;q.options=optionsFromWords([w,...distractorWords(w)],"meaning")
  }
  q.options=q.options||[];q.correctIndex=q.options.findIndex(o=>o.id===w.id||o.id==="syn-"+w.id);q.mode=mode;return q
}
function renderQuizQuestion(){
  if(quiz.index>=quiz.deck.length){finishQuiz();return}
  const w=quiz.deck[quiz.index];quiz.answered=false;quiz.question=makeQuestion(w,quiz.mode);
  const q=quiz.question;
  $("#quizCounter").textContent=`${quiz.index+1} / ${quiz.deck.length}`;$("#quizModeLabel").textContent=MODE_LABELS[q.mode]||"Quiz";$("#quizProgress").style.width=(quiz.index/quiz.deck.length*100)+"%";$("#questionTypeTag").textContent=MODE_LABELS[q.mode]||"Quiz";
  $("#questionPrompt").textContent=q.prompt;$("#quizWord").textContent=q.displayWord||"";$("#quizPhonetic").textContent=q.mode==="listening"?"":q.phonetic;
  $("#clozeSentence").hidden=q.mode!=="cloze";$("#clozeSentence").textContent=q.cloze||"";
  $("#listenAgainBtn").hidden=q.mode!=="listening";$("#quizAudioBtn").hidden=!(q.mode==="meaning"||q.mode==="reverse"||q.mode==="cloze"||q.mode==="context");
  $("#quizAudioBtn").onclick=()=>speak(w.word);$("#listenAgainBtn").onclick=()=>speak(w.word);
  $("#explanation").hidden=true;$("#nextQuestionBtn").disabled=true;
  $("#options").innerHTML=q.options.map((o,i)=>`<button class="option" data-option="${i}"><span class="letter">${String.fromCharCode(65+i)}</span><span>${esc(o.text)}</span></button>`).join("");
  $$("#options .option").forEach(b=>b.addEventListener("click",()=>answerQuiz(Number(b.dataset.option))));
  if(q.mode==="listening")setTimeout(()=>speak(w.word),250);
}
function answerQuiz(i){
  if(quiz.answered)return;quiz.answered=true;const q=quiz.question,w=q.target,c=ensure(w),correct=i===q.correctIndex;
  if(correct){c.correct++;c.box=Math.min(5,(c.box||0)+1);const days=[0,1,2,4,8,16][c.box]||16;c.due=Date.now()+days*86400000;quiz.score++;progress.correct++;progress.streak++}
  else{c.wrong++;c.box=Math.max(0,(c.box||0)-1);c.due=Date.now()+10*60*1000;progress.streak=0}
  progress.answered++;progress.lastStudy=Date.now();progress.mastered=words.filter(x=>ensure(x).box>=4).length;saveState();
  $$("#options .option").forEach((b,j)=>{b.classList.add("disabled");if(j===q.correctIndex)b.classList.add("correct");if(j===i&&!correct)b.classList.add("wrong")});
  explain(q,i,correct);$("#nextQuestionBtn").disabled=false;$("#quizHint").textContent=correct?"Đúng rồi. Hãy đọc lại phần giải thích để củng cố trí nhớ.":"Không sao. Đọc kỹ lý do và để app ôn lại từ này sớm hơn.";checkMilestone();renderHome()
}
function explain(q,choice,correct){
  const w=q.target,chosen=q.options[choice];$("#resultBadge").textContent=correct?"✓ Chính xác":"✕ Chưa đúng";$("#resultBadge").classList.toggle("wrong",!correct);$("#resultTitle").textContent=correct?"Bạn đã hiểu câu này.":"Hãy phân tích lại lý do.";
  let html="";
  if(q.mode==="meaning"||q.mode==="context"){
    html=`<p><b>Vì sao đúng?</b> “${esc(w.word)}” có nghĩa là <b>${esc(w.meaning)}</b>.`;
    if(w.context)html+=` Ngữ cảnh <b>${esc(w.context)}</b> giúp thu hẹp nghĩa phù hợp.`;
    html+=` Vì vậy đáp án <b>${String.fromCharCode(65+q.correctIndex)}</b> là đúng.</p>`;
    if(!correct)html+=`<p><b>Bạn chọn:</b> ${esc(chosen.text)}. Nghĩa này không khớp với “${esc(w.word)}”.</p>`;
    html+=explainOtherOptions(q);
  }else if(q.mode==="reverse"){
    html=`<p><b>Vì sao đúng?</b> Nghĩa <b>${esc(w.meaning)}</b> tương ứng với từ <b>${esc(w.word)}</b>.`;
    if(w.context)html+=` Trong ngữ cảnh <b>${esc(w.context)}</b>, cách dùng này vẫn giữ nghĩa trên.`;
    html+=`</p>`;
    if(!correct)html+=`<p><b>Bạn chọn:</b> ${esc(chosen.text)} — đó là một từ khác trong kho, không mang nghĩa này.</p>`;
    html+=explainOtherOptions(q);
  }else if(q.mode==="cloze"){
    html=`<p><b>Vì sao đúng?</b> Câu hoàn chỉnh là: <b>${esc(w.example||q.cloze.replace("_____ ",w.word+" "))}</b>. Từ <b>${esc(w.word)}</b> phù hợp cả về nghĩa lẫn ngữ cảnh.</p>`;
    if(!correct)html+=`<p><b>Bạn chọn:</b> ${esc(chosen.text)}. Khi đặt từ này vào câu, nghĩa sẽ không phù hợp với nội dung câu.</p>`;
    html+=explainOtherOptions(q);
  }else if(q.mode==="synonym"){
    const good=w.synonyms?.[0]||"";
    html=`<p><b>Vì sao đúng?</b> “${esc(good)}” là từ đồng nghĩa/gần nghĩa với <b>${esc(w.word)}</b>.`;
    if(w.context)html+=` Ví dụ: <b>${esc(w.context)}</b>.`;
    html+=`</p>`;
    if(!correct)html+=`<p><b>Bạn chọn:</b> ${esc(chosen.text)}. Từ này là synonym của <b>${esc(chosen.word?.word||"một từ khác")}</b>, không phải của “${esc(w.word)}”.</p>`;
    html+=`<p><b>Cách nhớ:</b> học theo cụm <b>${esc(w.word)} ↔ ${esc(good)}</b>.</p>`;
  }else if(q.mode==="listening"){
    html=`<p><b>Vì sao đúng?</b> Âm thanh phát ra là cách đọc của <b>${esc(w.word)}</b> ${w.phonetic?`(${esc(w.phonetic)})`:""} . Hãy đọc lại từ và tự nhắc nghĩa <b>${esc(w.meaning)}</b>.</p>`;
    if(!correct)html+=`<p><b>Bạn chọn:</b> ${esc(chosen.text)} — cách phát âm khác với từ vừa nghe.</p>`;
    html+=explainOtherOptions(q);
  }
  $("#explanationBody").innerHTML=html;
  $("#detailContext").textContent=w.context||"Chưa có";$("#detailSynonyms").textContent=w.synonyms?.join(", ")||"Chưa có";$("#detailExample").textContent=w.example||"Chưa có";$("#detailNote").textContent=w.note||"—";$("#explanation").hidden=false
}
function explainOtherOptions(q){
  const items=q.options.map((o,i)=>({o,i})).filter(x=>x.i!==q.correctIndex);
  return `<p><b>Vì sao các đáp án còn lại sai?</b></p><ul>${items.map(x=>{const o=x.o;const w=o.word;const reason=o.isSyn?`là synonym của “${esc(w.word)}”, không phải từ mục tiêu.`:`thuộc về từ “${esc(w.word)}”, có nghĩa là “${esc(w.meaning)}”.`;return `<li><b>${String.fromCharCode(65+x.i)}.</b> ${esc(o.text)} → ${reason}</li>`}).join("")}</ul>`
}
$("#nextQuestionBtn").addEventListener("click",()=>{quiz.index++;renderQuizQuestion()});
document.addEventListener("keydown",e=>{if(currentScreen==="quiz"){const n=Number(e.key);if(n>=1&&n<=4&&!quiz.answered)answerQuiz(n-1);if(e.key==="Enter"&&quiz.answered)$("#nextQuestionBtn").click()}if(e.key==="Escape")$("#celebrationModal").hidden=true});

function finishQuiz(){
  $("#quizProgress").style.width="100%";toast(`Hoàn thành! ${quiz.score}/${quiz.deck.length} câu đúng.`);renderHome();setTimeout(()=>go("home"),900)
}

function startFlashcards(){
  if(!words.length){$("#fcEmpty").hidden=false;return}$("#fcEmpty").hidden=true;fc={deck:shuffle(dueWords().length?dueWords():words).slice(0,Math.min(10,words.length)),index:0};renderFlashcard();$("#flashcard").classList.remove("flipped")
}
function renderFlashcard(){const w=fc.deck[fc.index];if(!w)return;$("#fcCounter").textContent=`${fc.index+1} / ${fc.deck.length}`;$("#fcProgress").style.width=(fc.index/fc.deck.length*100)+"%";$("#fcWord").textContent=w.word;$("#fcPhonetic").textContent=w.phonetic||"";$("#fcMeaning").textContent=w.meaning||"—";$("#fcContext").textContent=w.context||"—";$("#fcSynonyms").textContent=w.synonyms?.join(", ")||"—";$("#fcExample").textContent=w.example||"—";$("#fcAudioBtn").onclick=e=>{e.stopPropagation();speak(w.word)}}
$("#flashcard").addEventListener("click",()=>$("#flashcard").classList.toggle("flipped"));
$("#fcShuffleBtn").addEventListener("click",startFlashcards);
["fcBad","fcHard","fcGood","fcEasy"].forEach(id=>$("#"+id).addEventListener("click",()=>{
  const w=fc.deck[fc.index],c=ensure(w);if(id==="fcBad"){c.wrong++;c.box=0;c.due=Date.now()+10*60*1000}if(id==="fcHard"){c.wrong++;c.box=Math.max(1,c.box||0);c.due=Date.now()+86400000}if(id==="fcGood"){c.correct++;c.box=Math.min(5,(c.box||0)+1);c.due=Date.now()+([0,1,2,4,8,16][c.box]||16)*86400000}if(id==="fcEasy"){c.correct++;c.box=5;c.due=Date.now()+16*86400000}progress.mastered=words.filter(x=>ensure(x).box>=4).length;progress.lastStudy=Date.now();progress.answered++;saveState();checkMilestone();fc.index++;if(fc.index>=fc.deck.length){toast("Đã xong lượt flashcard!");go("home")}else{$("#flashcard").classList.remove("flipped");renderFlashcard()}}
));
let touchX=0;$("#flashcard").addEventListener("touchstart",e=>touchX=e.changedTouches[0].clientX,{passive:true});$("#flashcard").addEventListener("touchend",e=>{const dx=e.changedTouches[0].clientX-touchX;if(Math.abs(dx)<60)return;fc.index=Math.max(0,Math.min(fc.index+(dx<0?1:-1),fc.deck.length-1));$("#flashcard").classList.remove("flipped");renderFlashcard()},{passive:true});

function csvSplit(line){const out=[];let cur="",q=false;for(let i=0;i<line.length;i++){const ch=line[i];if(ch==='"'){if(q&&line[i+1]==='"'){cur+='"';i++}else q=!q}else if(ch===","&&!q){out.push(cur);cur=""}else cur+=ch}out.push(cur);return out}
function parseText(text){return text.split(/\r?\n/).map(x=>x.trim()).filter(Boolean).filter(x=>!x.startsWith("#")).map(line=>{const p=line.includes("|")?line.split("|"):csvSplit(line);if(p.length<3)return null;const [word,phonetic,meaning,context="",synonyms="",example="",note=""]=p.map(s=>s.trim());return word&&meaning?norm({word,phonetic,meaning,context,synonyms,example,note}):null}).filter(Boolean)}
function importWords(list){const map=new Map(words.map(w=>[w.word.toLowerCase(),w]));let add=0,up=0;for(const raw of list){const w=norm(raw),key=w.word.toLowerCase();if(map.has(key)){w.id=map.get(key).id;map.set(key,w);up++}else{map.set(key,w);add++}}words=[...map.values()].map(norm);words.forEach(ensure);progress.mastered=words.filter(x=>ensure(x).box>=4).length;saveState();renderHome();renderStats();return{add,up}}
function status(msg,error=false){const s=$("#importStatus");s.hidden=false;s.textContent=msg;s.classList.toggle("error",error)}
$("#fileInput").addEventListener("change",async e=>{const f=e.target.files?.[0];if(!f)return;const list=parseText(await f.text());if(!list.length)return status("Không có dòng hợp lệ.",true);const r=importWords(list);status(`Đã thêm ${r.add} từ, cập nhật ${r.up} từ.`)})
$$("[data-import-tab]").forEach(b=>b.addEventListener("click",()=>{$$("[data-import-tab]").forEach(x=>x.classList.remove("active"));b.classList.add("active");["file","paste","url"].forEach(t=>$("#import-"+t+"-pane").hidden=t!==b.dataset.importTab)}));
$("#importBtn").addEventListener("click",async()=>{const tab=$(".tab-btn.active").dataset.importTab;try{let text="";if(tab==="paste")text=$("#pasteInput").value;else if(tab==="url"){const u=$("#urlInput").value.trim();if(!u)throw Error("Hãy nhập URL CSV.");const r=await fetch(u);if(!r.ok)throw Error("Không tải được URL.");text=await r.text()}else{text=await $("#fileInput").files[0]?.text();if(!text)throw Error("Hãy chọn file.")}const list=parseText(text);if(!list.length)throw Error("Không tìm thấy dữ liệu hợp lệ.");const r=importWords(list);status(`Đã thêm ${r.add} từ, cập nhật ${r.up} từ.`)}catch(e){status(e.message||"Import thất bại.",true)}});
$("#loadSampleBtn").addEventListener("click",()=>{const r=importWords(SAMPLE);status(`Đã thêm ${r.add} từ mẫu.`)});
$("#deleteAllWordsBtn").addEventListener("click",()=>{
  if(!words.length){status("Kho từ vựng hiện đang trống.");return;}
  const ok=window.confirm(`Bạn có chắc muốn xóa toàn bộ ${words.length} từ vựng đã lưu? Dữ liệu ôn tập của các từ này cũng sẽ bị xóa. Thao tác không thể hoàn tác.`);
  if(!ok)return;
  const removed=words.length;words=[];progress.cards={};progress.mastered=0;
  quiz={deck:[],index:0,score:0,answered:false,mode:"smart",question:null,options:[],correctIndex:-1};fc={deck:[],index:0};
  saveState();renderHome();renderStats();renderMistakes();status(`Đã xóa toàn bộ ${removed} từ vựng.`);toast("Đã xóa toàn bộ từ vựng.");
});
$("#copyFormatBtn").addEventListener("click",()=>{navigator.clipboard?.writeText($("#formatText").textContent);toast("Đã copy mẫu.")});

function renderMistakes(){
  const weak=weakWords().slice(0,15);$("#mistakeSummary").textContent=weak.length?`Có ${weakWords().length} từ từng trả lời sai. App sẽ ưu tiên chúng trong Smart Quiz.`:"Bạn chưa có từ sai. Làm quiz để app bắt đầu phát hiện từ yếu.";
  $("#mistakeList").innerHTML=weak.length?weak.map(w=>{const c=ensure(w);return`<div class="mistake-item"><div><b>${esc(w.word)}</b><small>${esc(w.meaning)}</small></div><span class="weak-meter">${c.wrong} sai / ${c.correct} đúng</span></div>`}).join(""):`<div class="empty-state"><div class="empty-emoji">🌱</div><h3>Chưa có dữ liệu</h3><p>Hãy làm vài câu quiz trước nhé.</p></div>`
}
$("#mistakeQuizBtn").addEventListener("click",()=>{if(!weakWords().length)return toast("Chưa có từ yếu để ôn.");currentQuizMode="smart";go("quiz")});

function renderStats(){
  $("#sWords").textContent=words.length;$("#sAnswered").textContent=progress.answered;$("#sCorrect").textContent=progress.correct;$("#sAccuracy").textContent=progress.answered?Math.round(progress.correct/progress.answered*100)+"%":"0%";$("#sMastered").textContent=progress.mastered||0;$("#masteredProgress").style.width=(words.length?Math.min(100,(progress.mastered||0)/words.length*100):0)+"%";
  const due=dueWords().slice(0,5),weak=weakWords().slice(0,5);$("#dueList").innerHTML=due.length?due.map(w=>`<div class="due-item"><b>${esc(w.word)}</b><span>${esc(w.meaning)}</span></div>`).join(""):`<p style="color:var(--muted)">Chưa có từ cần ôn ngay.</p>`;$("#weakList").innerHTML=weak.length?weak.map(w=>{const c=ensure(w);return`<div class="due-item"><b>${esc(w.word)}</b><span>${c.wrong} sai / ${c.correct} đúng</span></div>`}).join(""):`<p style="color:var(--muted)">Chưa có dữ liệu sai.</p>`
}

function renderSettings(){
  const p=("Notification"in window)?Notification.permission:"denied";$("#notifySwitch").classList.toggle("on",settings.notifications||p==="granted");$("#awaySwitch").classList.toggle("on",settings.awayReminder);
  $("#reminderList").innerHTML=settings.reminderTimes.map((t,i)=>`<div class="reminder-row"><input type="time" value="${t}" data-reminder="${i}"><button class="remove-reminder" data-remove-reminder="${i}">×</button></div>`).join("");
  $$("[data-reminder]").forEach(x=>x.addEventListener("change",e=>{settings.reminderTimes[Number(e.target.dataset.reminder)]=e.target.value;saveState();scheduleOpenReminder()}));
  $$("[data-remove-reminder]").forEach(x=>x.addEventListener("click",()=>{settings.reminderTimes.splice(Number(x.dataset.removeReminder),1);saveState();renderSettings()}))
}
$("#awaySwitch").addEventListener("click",()=>{settings.awayReminder=!settings.awayReminder;saveState();renderSettings()});
$("#addReminderBtn").addEventListener("click",()=>{settings.reminderTimes.push("21:00");saveState();renderSettings()});
$("#notifySwitch").addEventListener("click",async()=>{if(!("Notification"in window))return toast("Trình duyệt không hỗ trợ.");const p=await Notification.requestPermission();settings.notifications=p==="granted";saveState();renderSettings()});
$("#testNotifBtn").addEventListener("click",async()=>{if(!("Notification"in window))return toast("Trình duyệt không hỗ trợ.");const p=await Notification.requestPermission();if(p!=="granted")return toast("Bạn chưa cho phép thông báo.");new Notification("Vocab Master 📚",{body:"Đến lúc học vài từ rồi! Cố lên nhé ✨",icon:"assets/icon-192.png"})});
function scheduleOpenReminder(){clearTimeout(window.__reminder);if(!settings.notifications||!settings.reminderTimes.length)return;const now=new Date();let best=null;for(const t of settings.reminderTimes){const[h,m]=t.split(":").map(Number);const d=new Date(now);d.setHours(h,m,0,0);if(d<=now)d.setDate(d.getDate()+1);if(!best||d<best)best=d}window.__reminder=setTimeout(()=>{if(Notification.permission==="granted")new Notification("Vocab Master 📚",{body:"Đến giờ học rồi. Làm 5 câu thôi cũng được! ✨",icon:"assets/icon-192.png"});scheduleOpenReminder()},Math.min(best-now,2147483647))}
function checkAway(){if(!settings.notifications||!settings.awayReminder||!progress.lastStudy)return;const h=(Date.now()-progress.lastStudy)/3600000;if(h>=24)toast("Bạn đã hơn 24h chưa học — làm 5 câu nhé!");else if(h>=12)toast("Đã 12h rồi — quay lại ôn vài từ nhé!");else if(h>=4)toast("Đã 4h rồi — tranh thủ ôn vài từ nhé!")}

function checkMilestone(){const m=Math.floor((progress.mastered||0)/10);if(m>0&&m>(progress.milestones||0)){progress.milestones=m;saveState();$("#celebrationTitle").textContent=`Bạn đã nhớ thêm ${m*10} từ!`;$("#celebrationText").textContent="Tuyệt vời! Đọc lại phần giải thích rồi tiếp tục nhé.";$("#celebrationModal").hidden=false}}
$$("[data-close='celebration']").forEach(x=>x.addEventListener("click",()=>$("#celebrationModal").hidden=true));

let deferredPrompt=null;window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredPrompt=e;$("#installBtn").hidden=false});$("#installBtn").addEventListener("click",async()=>{if(!deferredPrompt)return toast("Mở menu trình duyệt → Cài ứng dụng.");deferredPrompt.prompt();await deferredPrompt.userChoice;deferredPrompt=null;$("#installBtn").hidden=true});

if("serviceWorker"in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(console.warn));
loadState();words=words.map(norm);words.forEach(ensure);saveState();renderHome();checkAway();scheduleOpenReminder();
