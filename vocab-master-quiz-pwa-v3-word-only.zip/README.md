# Vocab Master Quiz PWA v3

## Có gì mới?
1. English -> Vietnamese
2. Vietnamese -> English
3. Fill in the blank
4. Synonym
5. Listening
6. Context
7. Smart Quiz: ưu tiên từ yếu/cần ôn và tự đổi dạng câu.
8. Sau mỗi câu có giải thích vì sao đúng + vì sao từng đáp án khác sai.
9. Flashcard 3D + swipe.
10. Từ hay sai riêng để recovery.
11. Spaced review bằng box + due date.
12. LocalStorage.
13. PWA manifest + service worker.
14. Icon PWA/Android dùng bộ icon Kirby người dùng cung cấp.
15. Notification API + reminder khi app/trang đang hoạt động.

## Dữ liệu
word | phonetic | meaning | context | synonyms | example | note

Google Sheets:
- tạo bảng đúng 7 cột;
- File -> Download -> CSV để import;
- hoặc Publish to web -> CSV rồi dùng URL công khai.

## Chạy
- Mở folder bằng VS Code.
- Cài Live Server.
- index.html -> Go Live.
- Để cài PWA trên điện thoại, deploy lên HTTPS (Netlify/Vercel).
- Notification nền khi app đã đóng hoàn toàn vẫn cần Web Push + backend; frontend không thể đảm bảo hẹn giờ nền bằng setTimeout.
